import type { Product } from './types'
export function getAvailableStock(p: Product): number {
  const onHand = (p as unknown as { stock_quantity?: number; quantity_on_hand?: number }).stock_quantity
    ?? (p as unknown as { quantity_on_hand?: number }).quantity_on_hand
    ?? 0
  const reserved = (p as unknown as { reserved_quantity?: number }).reserved_quantity ?? 0
  return Math.max(0, onHand - reserved)
}
export function isLowStock(p: Product): boolean { return getAvailableStock(p) <= p.min_stock }
export function isOutOfStock(p: Product): boolean { return getAvailableStock(p) <= 0 }
export function formatPrice(amount: number, currency = 'ر.ي'): string {
  return `${new Intl.NumberFormat('ar', { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(amount)} ${currency}`
}
export function getPriceForTier(p: Product, tier: string | number): number {
  const tierStr = String(tier)
  if (tierStr === 'wholesale_of_wholesale' || tierStr === '1') return p.base_price
  if (tierStr === 'wholesale' || tierStr === '2') return p.wholesale_price
  return p.retail_price
}
