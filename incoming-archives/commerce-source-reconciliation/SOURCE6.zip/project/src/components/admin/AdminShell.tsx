import { useState, useEffect } from 'react'
import { Link, Outlet, useNavigate, useLocation } from 'react-router-dom'
import { LayoutDashboard, ShoppingCart, Users, Package, Database, Brain, ChartBar as BarChart3, Settings, Shield, LogOut, Menu, X, Bell, Search, FileText, Warehouse, ChevronLeft, Wrench } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { cn } from '@/lib/utils'

const adminNav: { section: string; items: { to: string; label: string; icon: typeof LayoutDashboard; exact?: boolean }[] }[] = [
  {
    section: 'الرئيسية',
    items: [{ to: '/admin', label: 'لوحة المعلومات', icon: LayoutDashboard, exact: true }],
  },
  {
    section: 'المبيعات',
    items: [
      { to: '/admin/orders', label: 'الطلبات', icon: ShoppingCart },
      { to: '/admin/customers', label: 'العملاء', icon: Users },
    ],
  },
  {
    section: 'المنتجات',
    items: [
      { to: '/admin/catalog', label: 'الكتالوج', icon: Package },
      { to: '/admin/pricing', label: 'التسعير', icon: FileText },
    ],
  },
  {
    section: 'البيانات',
    items: [
      { to: '/admin/data-center', label: 'مركز البيانات', icon: Database },
      { to: '/admin/import', label: 'الاستيراد', icon: Warehouse },
      { to: '/admin/import-logs', label: 'سجلات الاستيراد', icon: FileText },
    ],
  },
  {
    section: 'الذكاء الاصطناعي',
    items: [
      { to: '/admin/ai', label: 'مركز AI', icon: Brain },
      { to: '/admin/ai/reports', label: 'تقارير AI', icon: BarChart3 },
      { to: '/admin/ai/alerts', label: 'تنبيهات AI', icon: Bell },
      { to: '/admin/ai/tasks', label: 'مهام AI', icon: Brain },
    ],
  },
  {
    section: 'النظام',
    items: [
      { to: '/admin/reports', label: 'التقارير', icon: BarChart3 },
      { to: '/admin/users', label: 'المستخدمون', icon: Shield },
      { to: '/admin/audit', label: 'سجل النظام', icon: FileText },
      { to: '/admin/notifications', label: 'الإشعارات', icon: Bell },
      { to: '/admin/health', label: 'صحة النظام', icon: Wrench },
    ],
  },
  {
    section: 'الإعدادات',
    items: [
      { to: '/admin/settings', label: 'الإعدادات', icon: Settings },
    ],
  },
]

export function AdminShell() {
  const { user, signOut } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [collapsed, setCollapsed] = useState(false)

  const isActive = (to: string, exact?: boolean) =>
    exact ? location.pathname === to : location.pathname.startsWith(to)

  return (
    <div className="min-h-screen bg-neutral-50 flex" dir="rtl">
      {/* Sidebar */}
      <aside className={cn(
        'fixed lg:sticky top-0 right-0 z-50 h-screen bg-neutral-900 text-neutral-300 transition-all duration-300 flex flex-col',
        collapsed ? 'w-16' : 'w-64',
        sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
      )}>
        {/* Logo */}
        <div className="flex items-center gap-2 h-16 px-4 border-b border-neutral-800 shrink-0">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary-600 text-white font-bold shrink-0">أ</div>
          {!collapsed && (
            <div className="overflow-hidden">
              <span className="text-base font-bold text-white block whitespace-nowrap">الأغبري</span>
              <span className="text-[10px] text-neutral-500 block whitespace-nowrap">لوحة التحكم</span>
            </div>
          )}
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden mr-auto text-neutral-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto scrollbar-thin py-4">
          {adminNav.map(group => (
            <div key={group.section} className="mb-4">
              {!collapsed && (
                <h3 className="px-4 mb-2 text-[11px] font-semibold text-neutral-500 uppercase tracking-wider">{group.section}</h3>
              )}
              <div className="space-y-0.5 px-2">
                {group.items.map(item => (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={() => setSidebarOpen(false)}
                    className={cn(
                      'flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors',
                      isActive(item.to, item.exact)
                        ? 'bg-primary-600 text-white'
                        : 'text-neutral-400 hover:bg-neutral-800 hover:text-white'
                    )}
                    title={collapsed ? item.label : undefined}
                  >
                    <item.icon className="h-5 w-5 shrink-0" />
                    {!collapsed && <span className="whitespace-nowrap">{item.label}</span>}
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </nav>

        {/* Footer */}
        <div className="border-t border-neutral-800 p-3 shrink-0">
          <button
            onClick={() => { signOut(); navigate('/') }}
            className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-neutral-400 hover:bg-neutral-800 hover:text-white w-full"
            title={collapsed ? 'خروج' : undefined}
          >
            <LogOut className="h-5 w-5 shrink-0" />
            {!collapsed && <span>تسجيل الخروج</span>}
          </button>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {sidebarOpen && <div className="fixed inset-0 z-40 bg-neutral-900/50 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      {/* Main area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top bar */}
        <header className="sticky top-0 z-30 bg-white border-b border-neutral-200 h-16 flex items-center justify-between px-4 gap-4">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden btn-icon btn-ghost">
              <Menu className="h-5 w-5" />
            </button>
            <button onClick={() => setCollapsed(!collapsed)} className="hidden lg:flex btn-icon btn-ghost">
              <ChevronLeft className={cn('h-5 w-5 transition-transform', collapsed && 'rotate-180')} />
            </button>
            <Link to="/" className="text-sm text-neutral-500 hover:text-primary-600 hidden sm:block">
              ← العودة للمتجر
            </Link>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden md:flex items-center gap-2 rounded-lg bg-neutral-100 px-3 py-2 text-sm text-neutral-400 w-64">
              <Search className="h-4 w-4" />
              <span>بحث سريع...</span>
              <kbd className="mr-auto text-xs bg-white rounded px-1.5 py-0.5 border border-neutral-200">⌘K</kbd>
            </div>
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary-100 text-primary-700 text-sm font-bold">
              {user?.email?.[0]?.toUpperCase() || 'A'}
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          <Outlet />
        </div>
      </div>
    </div>
  )
}
