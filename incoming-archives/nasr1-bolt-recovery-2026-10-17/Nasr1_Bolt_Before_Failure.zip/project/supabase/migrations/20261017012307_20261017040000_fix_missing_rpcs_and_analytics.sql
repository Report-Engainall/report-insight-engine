/*
# Fix missing RPCs and executive analytics bug

1. New Functions
- fetch_staff_products(p_product_id uuid) — SECURITY DEFINER returns products for staff org
- get_ai_gateway_budget() — SECURITY DEFINER returns AI budget + usage for current org
- configure_ai_usage_budget(p_settings jsonb) — SECURITY DEFINER upserts AI budget

2. Modified Functions
- get_executive_analytics() — dropped and recreated to fix oi.product_code → oi.item_code

3. Security
- All functions SECURITY DEFINER, SET search_path = public
- EXECUTE revoked from anon, granted to authenticated
- Tenant from current_profile_id(), never caller-supplied
*/

-- Drop existing get_executive_analytics to change return type
DROP FUNCTION IF EXISTS public.get_executive_analytics() CASCADE;

-- ─── fetch_staff_products ───
CREATE OR REPLACE FUNCTION public.fetch_staff_products(p_product_id uuid DEFAULT NULL)
RETURNS SETOF json
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_profile_id uuid;
  v_org_id uuid;
BEGIN
  v_profile_id := public.current_profile_id();
  IF v_profile_id IS NULL THEN
    RAISE EXCEPTION 'لم يتم التعرف على هوية المستخدم الحالي.';
  END IF;
  IF NOT public.is_staff() THEN
    RAISE EXCEPTION 'لا تملك صلاحية الوصول إلى بيانات الأصناف الإدارية.';
  END IF;
  SELECT organization_id INTO v_org_id FROM public.profiles WHERE id = v_profile_id;
  IF v_org_id IS NULL THEN
    RAISE EXCEPTION 'لم يتم العثور على مؤسسة مرتبطة بحسابك.';
  END IF;

  IF p_product_id IS NOT NULL THEN
    RETURN QUERY
      SELECT to_json(p.*) FROM public.products p
      WHERE p.id = p_product_id AND p.organization_id = v_org_id;
  ELSE
    RETURN QUERY
      SELECT to_json(p.*) FROM public.products p
      WHERE p.organization_id = v_org_id
      ORDER BY p.name;
  END IF;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.fetch_staff_products FROM anon;
GRANT EXECUTE ON FUNCTION public.fetch_staff_products TO authenticated;

-- ─── get_ai_gateway_budget ───
CREATE OR REPLACE FUNCTION public.get_ai_gateway_budget()
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_profile_id uuid;
  v_org_id uuid;
  v_budget public.ai_usage_budgets%ROWTYPE;
  v_today_cost numeric := 0;
  v_month_cost numeric := 0;
  v_today_tokens bigint := 0;
  v_month_tokens bigint := 0;
BEGIN
  v_profile_id := public.current_profile_id();
  IF v_profile_id IS NULL THEN
    RAISE EXCEPTION 'لم يتم التعرف على هوية المستخدم الحالي.';
  END IF;
  IF NOT public.is_staff() THEN
    RAISE EXCEPTION 'لا تملك صلاحية عرض إعدادات الذكاء الاصطناعي.';
  END IF;
  SELECT organization_id INTO v_org_id FROM public.profiles WHERE id = v_profile_id;
  IF v_org_id IS NULL THEN
    RAISE EXCEPTION 'لم يتم العثور على مؤسسة مرتبطة بحسابك.';
  END IF;

  SELECT * INTO v_budget FROM public.ai_usage_budgets WHERE organization_id = v_org_id LIMIT 1;

  SELECT COALESCE(SUM(estimated_cost), 0), COALESCE(SUM(input_tokens + output_tokens), 0)
    INTO v_today_cost, v_today_tokens
  FROM public.ai_usage_ledger
  WHERE organization_id = v_org_id AND created_at >= date_trunc('day', now());

  SELECT COALESCE(SUM(estimated_cost), 0), COALESCE(SUM(input_tokens + output_tokens), 0)
    INTO v_month_cost, v_month_tokens
  FROM public.ai_usage_ledger
  WHERE organization_id = v_org_id AND created_at >= date_trunc('month', now());

  RETURN json_build_object(
    'organization_id', v_org_id,
    'configured', v_budget.id IS NOT NULL,
    'ai_enabled', COALESCE(v_budget.ai_enabled, false),
    'fallback_enabled', COALESCE(v_budget.fallback_enabled, false),
    'primary_provider', 'openai_compatible',
    'primary_model', '',
    'primary_base_url', '',
    'fallback_provider', 'gemini',
    'fallback_model', '',
    'fallback_base_url', '',
    'daily_cost_limit', COALESCE(v_budget.daily_cost_limit, 0),
    'monthly_cost_limit', COALESCE(v_budget.monthly_cost_limit, 0),
    'daily_token_limit', COALESCE(v_budget.daily_token_limit, 0),
    'monthly_token_limit', COALESCE(v_budget.monthly_token_limit, 0),
    'per_request_cost_limit', COALESCE(v_budget.per_request_cost_limit, 0),
    'today_cost', v_today_cost,
    'month_cost', v_month_cost,
    'today_tokens', v_today_tokens,
    'month_tokens', v_month_tokens,
    'reserved_cost', 0,
    'keys_stored_in_database', false
  );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.get_ai_gateway_budget FROM anon;
GRANT EXECUTE ON FUNCTION public.get_ai_gateway_budget TO authenticated;

-- ─── configure_ai_usage_budget ───
CREATE OR REPLACE FUNCTION public.configure_ai_usage_budget(p_settings jsonb)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_profile_id uuid;
  v_org_id uuid;
  v_ai_enabled boolean;
  v_fallback_enabled boolean;
  v_daily_cost_limit numeric;
  v_monthly_cost_limit numeric;
  v_daily_token_limit integer;
  v_monthly_token_limit integer;
  v_per_request_cost_limit numeric;
BEGIN
  v_profile_id := public.current_profile_id();
  IF v_profile_id IS NULL THEN
    RAISE EXCEPTION 'لم يتم التعرف على هوية المستخدم الحالي.';
  END IF;
  IF NOT public.is_staff() THEN
    RAISE EXCEPTION 'لا تملك صلاحية تعديل إعدادات الذكاء الاصطناعي.';
  END IF;
  SELECT organization_id INTO v_org_id FROM public.profiles WHERE id = v_profile_id;
  IF v_org_id IS NULL THEN
    RAISE EXCEPTION 'لم يتم العثور على مؤسسة مرتبطة بحسابك.';
  END IF;

  v_ai_enabled := COALESCE((p_settings->>'ai_enabled')::boolean, false);
  v_fallback_enabled := COALESCE((p_settings->>'fallback_enabled')::boolean, false);
  v_daily_cost_limit := COALESCE((p_settings->>'daily_cost_limit')::numeric, 0);
  v_monthly_cost_limit := COALESCE((p_settings->>'monthly_cost_limit')::numeric, 0);
  v_daily_token_limit := COALESCE((p_settings->>'daily_token_limit')::integer, 0);
  v_monthly_token_limit := COALESCE((p_settings->>'monthly_token_limit')::integer, 0);
  v_per_request_cost_limit := COALESCE((p_settings->>'per_request_cost_limit')::numeric, 0);

  INSERT INTO public.ai_usage_budgets
    (organization_id, ai_enabled, fallback_enabled, daily_cost_limit, monthly_cost_limit,
     daily_token_limit, monthly_token_limit, per_request_cost_limit, updated_by, updated_at)
  VALUES
    (v_org_id, v_ai_enabled, v_fallback_enabled, v_daily_cost_limit, v_monthly_cost_limit,
     v_daily_token_limit, v_monthly_token_limit, v_per_request_cost_limit, v_profile_id, now())
  ON CONFLICT (organization_id)
  DO UPDATE SET
    ai_enabled = EXCLUDED.ai_enabled,
    fallback_enabled = EXCLUDED.fallback_enabled,
    daily_cost_limit = EXCLUDED.daily_cost_limit,
    monthly_cost_limit = EXCLUDED.monthly_cost_limit,
    daily_token_limit = EXCLUDED.daily_token_limit,
    monthly_token_limit = EXCLUDED.monthly_token_limit,
    per_request_cost_limit = EXCLUDED.per_request_cost_limit,
    updated_by = EXCLUDED.updated_by,
    updated_at = EXCLUDED.updated_at;

  RETURN public.get_ai_gateway_budget();
END;
$$;

REVOKE EXECUTE ON FUNCTION public.configure_ai_usage_budget FROM anon;
GRANT EXECUTE ON FUNCTION public.configure_ai_usage_budget TO authenticated;

-- ─── Recreate get_executive_analytics with fixed column references ───
CREATE OR REPLACE FUNCTION public.get_executive_analytics()
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_profile_id uuid;
  v_org_id uuid;
  v_result json;
BEGIN
  v_profile_id := public.current_profile_id();
  IF v_profile_id IS NULL THEN
    RAISE EXCEPTION 'لم يتم التعرف على هوية المستخدم الحالي.';
  END IF;
  IF NOT public.is_staff() THEN
    RAISE EXCEPTION 'لا تملك صلاحية عرض لوحة التحليلات التنفيذية.';
  END IF;
  SELECT organization_id INTO v_org_id FROM public.profiles WHERE id = v_profile_id;
  IF v_org_id IS NULL THEN
    RAISE EXCEPTION 'لم يتم العثور على مؤسسة مرتبطة بحسابك.';
  END IF;

  SELECT json_build_object(
    'generated_at', now(),
    'kpis', json_build_object(
      'total_orders', (SELECT count(*) FROM public.orders WHERE organization_id = v_org_id),
      'total_sales', (SELECT COALESCE(sum(total_amount), 0) FROM public.orders WHERE organization_id = v_org_id AND status NOT IN ('cancelled','rejected')),
      'pending_orders', (SELECT count(*) FROM public.orders WHERE organization_id = v_org_id AND status IN ('new','reviewing','returned')),
      'approved_orders', (SELECT count(*) FROM public.orders WHERE organization_id = v_org_id AND status IN ('approved','preparing','prepared','dispatched','delivered')),
      'total_customers', (SELECT count(*) FROM public.customers WHERE organization_id = v_org_id),
      'active_products', (SELECT count(*) FROM public.products WHERE organization_id = v_org_id AND status = 'active'),
      'low_stock_count', (SELECT count(*) FROM public.products p WHERE p.organization_id = v_org_id AND p.status = 'active' AND p.min_stock > 0 AND EXISTS (SELECT 1 FROM public.inventory_balances ib WHERE ib.product_id = p.id AND ib.quantity_on_hand <= p.min_stock))
    ),
    'top_products', COALESCE(
      (SELECT json_agg(t) FROM (
        SELECT oi.item_code, oi.product_name_snapshot AS name,
               sum(oi.quantity) AS qty, sum(oi.line_total) AS revenue
        FROM public.order_items oi
        JOIN public.orders o ON o.id = oi.order_id
        WHERE o.organization_id = v_org_id AND o.status NOT IN ('cancelled','rejected')
        GROUP BY oi.item_code, oi.product_name_snapshot
        ORDER BY revenue DESC NULLS LAST
        LIMIT 10
      ) t),
      '[]'::json
    ),
    'recent_orders', COALESCE(
      (SELECT json_agg(t) FROM (
        SELECT o.id, o.order_number, o.status, o.total_amount, o.created_at,
               c.business_name AS customer_name
        FROM public.orders o
        LEFT JOIN public.customers c ON c.id = o.customer_id
        WHERE o.organization_id = v_org_id
        ORDER BY o.created_at DESC
        LIMIT 10
      ) t),
      '[]'::json
    ),
    'status_breakdown', COALESCE(
      (SELECT json_agg(t) FROM (
        SELECT status, count(*) AS count
        FROM public.orders WHERE organization_id = v_org_id
        GROUP BY status
      ) t),
      '[]'::json
    )
  ) INTO v_result;

  RETURN v_result;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.get_executive_analytics FROM anon;
GRANT EXECUTE ON FUNCTION public.get_executive_analytics TO authenticated;
